# backend/app/lotto/lotto_selenium_fetch.py
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


def fetch_lotto_bywin_selenium(draw_no: int) -> dict:
    url = f"https://www.dhlottery.co.kr/gameResult.do?method=byWin&drwNo={draw_no}"

    options = Options()
    # 눈으로 확인하고 싶으면 아래 줄 주석 처리
    options.add_argument("--headless=new")

    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--window-size=1280,900")
    options.add_argument("--lang=ko-KR")

    driver = webdriver.Chrome(options=options)
    wait = WebDriverWait(driver, 15)

    try:
        driver.get(url)

        # 당첨번호 6개가 뜰 때까지 기다림
        balls = wait.until(
            EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".win_result .num.win span"))
        )
        nums = [int(b.text.strip()) for b in balls if b.text.strip().isdigit()]

        # 보너스 번호
        bonus_el = wait.until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".win_result .num.bonus span"))
        )
        bonus = int(bonus_el.text.strip())

        # 추첨일(텍스트에서 파싱)
        # 예: "903회 당첨결과 (2020년 03월 14일 추첨)"
        title = driver.find_element(By.CSS_SELECTOR, ".win_result h4").text.strip()

        return {
            "draw_no": draw_no,
            "title": title,
            "numbers": nums[:6],
            "bonus": bonus,
            "url": url,
        }

    finally:
        driver.quit()


if __name__ == "__main__":
    data = fetch_lotto_bywin_selenium(903)
    print(data)