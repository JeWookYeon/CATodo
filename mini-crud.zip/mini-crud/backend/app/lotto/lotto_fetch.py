# lotto_fetch_one.py
import requests

URL_HOME = "https://www.dhlottery.co.kr/"
URL_API  = "https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo={}"

def fetch_one(drw_no: int) -> dict:
    s = requests.Session()
    s.headers.update({
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "ko-KR,ko;q=0.9,en;q=0.8",
        "Referer": URL_HOME,
        "Connection": "keep-alive",
    })

    # 1) 먼저 홈을 한번 찍어서 쿠키/세션을 받는다
    s.get(URL_HOME, timeout=10)

    # 2) API 호출
    r = s.get(URL_API.format(drw_no), timeout=10, allow_redirects=True)

    ct = r.headers.get("Content-Type", "")
    if "application/json" not in ct:
        # JSON이 아니면(대부분 HTML) 원인 진단용 정보 출력
        raise RuntimeError(
            "JSON이 아니라 HTML/리다이렉트가 내려왔습니다.\n"
            f"- status={r.status_code}\n"
            f"- final_url={r.url}\n"
            f"- content_type={ct}\n"
            f"- head(300)={r.text[:300]!r}\n"
        )

    return r.json()

if __name__ == "__main__":
    data = fetch_one(1)
    print(data)